package com.cocbot

import android.graphics.PointF
import android.os.SystemClock
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

/**
 * Durum makinesi: her karede önce sahneyi tanı, tanınmazsa HİÇBİR YERE DOKUNMA.
 * Döngü: Ekran 1 → 2 → 3 → 4 → (savaş) → 5 → Ekran 1 ...
 */
class BotLoop(private val svc: BotService) {

    companion object {
        const val WAIT_MS = 2000L          // dokunuş sonrası ekran değişimi bekleme üst sınırı
        const val MAX_ATTEMPTS = 3         // aynı sahnede art arda en fazla deneme
        const val LOOT_LIMIT = 3_000_000L  // altın + iksir bunu geçerse saldır
        const val TAP_GAP_MS = 300L        // sahne promptu: dış alan dokunuşları arası ~0,3 sn
        const val UNKNOWN_WARN_MS = 30_000L
        const val BATTLE_WARN_MS = 240_000L

        // Ekran 4: asker kartı ve 20 dış alan noktası (referans koordinat)
        const val CARD_X = 326
        const val CARD_Y = 1395
        val DEPLOY = arrayOf(
            intArrayOf(560, 190), intArrayOf(700, 200), intArrayOf(800, 160), intArrayOf(850, 270), intArrayOf(700, 330),
            intArrayOf(600, 330), intArrayOf(800, 380), intArrayOf(480, 450), intArrayOf(600, 470), intArrayOf(480, 580),
            intArrayOf(2200, 800), intArrayOf(2300, 780), intArrayOf(2380, 700), intArrayOf(2280, 900), intArrayOf(2170, 920),
            intArrayOf(2060, 860), intArrayOf(2060, 1000), intArrayOf(1960, 1090), intArrayOf(1850, 1170), intArrayOf(1700, 1200)
        )

        // Ekran 4 "BASILMAYACAK YERLER" (x0,y0,x1,y1) - bırakma noktaları buralara düşemez
        val FORBIDDEN = arrayOf(
            intArrayOf(0, 0, 520, 345),        // rakip adı / ganimet
            intArrayOf(1900, 0, 2419, 330),    // sağ üst sayaçlar
            intArrayOf(1000, 0, 1420, 150),    // geri sayım
            intArrayOf(20, 1140, 1070, 1250),  // Savaşı Bitir + güçlendirme kutuları
            intArrayOf(0, 1270, 2419, 1512),   // alt kartlar
            intArrayOf(2030, 1050, 2419, 1250) // İleri
        )
    }

    private val pt = PointF()

    private var lastTapScene: Scene? = null
    private var lastTapAt = 0L
    private var attempts = 0
    private var unknownSince = 0L

    // Ekran 4 durumu
    private var deployed = false
    private var pending: Pair<Long, Long>? = null
    private var prevVillage: Pair<Long, Long>? = null
    private var ileriAt = 0L
    private var ileriTries = 0

    suspend fun run() {
        while (svc.running) {
            try {
                step()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                svc.log("Hata: ${e.javaClass.simpleName}")
                delay(100)
            }
        }
    }

    private suspend fun step() {
        val frame = svc.grab()
        if (frame == null) {          // OS ekran görüntüsü hız sınırı vb.: kısa bekle, tekrar al
            delay(40)
            return
        }
        try {
            val scene = Scenes.detect(frame.small)
            handle(frame, scene)
        } finally {
            frame.recycle()
        }
    }

    private suspend fun handle(frame: Frame, scene: Scene?) {
        val now = SystemClock.elapsedRealtime()

        if (scene == null) {
            if (unknownSince == 0L) unknownSince = now
            val limit = if (deployed) BATTLE_WARN_MS else UNKNOWN_WARN_MS
            when {
                now - unknownSince > limit -> svc.log("⚠ Bilinmeyen ekran (dokunulmuyor)")
                deployed -> svc.log("Savaş sürüyor…")
                else -> svc.log("Ekran bekleniyor…")
            }
            return
        }
        unknownSince = 0L

        if (scene != Scene.ATTACK_PREP) {
            deployed = false
            pending = null
            prevVillage = null
            ileriTries = 0
        }

        when (scene) {
            Scene.HOME -> act(frame, scene, now, 147, 1375, "Savaş")
            Scene.WAR_MENU -> act(frame, scene, now, 383, 1060, "Eşleşme Bul")
            Scene.ARMY -> act(frame, scene, now, 2050, 1238, "Saldır!")
            Scene.RESULT -> act(frame, scene, now, 1210, 1295, "Eve Dön")
            Scene.ATTACK_PREP -> attackPrep(frame, now)
        }
    }

    /** Tek dokunuşluk sahneler: dokununca ekran değişimini bekle (en fazla 2 sn), sonra tek tek yeniden dene. */
    private suspend fun act(frame: Frame, scene: Scene, now: Long, xRef: Int, yRef: Int, label: String) {
        if (scene == lastTapScene) {
            if (now - lastTapAt < WAIT_MS) {
                svc.log("$label sonrası ekran bekleniyor")
                return
            }
            if (attempts >= MAX_ATTEMPTS) {
                svc.stopWithWarning("⚠ Ekran değişmedi ($label), durdu")
                return
            }
        } else {
            attempts = 0
        }
        attempts++
        lastTapScene = scene
        lastTapAt = now
        svc.log(label)
        tapRef(frame, xRef.toFloat(), yRef.toFloat())
    }

    private suspend fun attackPrep(frame: Frame, now: Long) {
        if (deployed) {
            svc.log("Savaş sürüyor…")
            return
        }
        // Ganimet: sarı altın (y≈178) ve pembe iksir (y≈245); kara iksir okunmaz
        val gold = Ocr.readNumber(frame.full, 110, 150, 340, 205)
        val elixir = Ocr.readNumber(frame.full, 110, 222, 340, 275)
        if (gold == null || elixir == null) {
            pending = null
            svc.log("Ganimet okunamıyor…")
            return
        }
        val cur = gold to elixir

        // İleri'den sonra eski köy hâlâ görünüyorsa yeni köyü bekle (en fazla 2 sn)
        if (cur == prevVillage && now - ileriAt < WAIT_MS) {
            pending = null
            svc.log("Yeni köy bekleniyor…")
            return
        }
        // Yanlış okumaya karşı: iki ardışık karede aynı değer
        if (cur != pending) {
            pending = cur
            svc.log("Ganimet okunuyor…")
            return
        }

        if (prevVillage != null && cur != prevVillage) ileriTries = 0   // yeni köy yüklendi

        val total = gold + elixir
        if (total <= LOOT_LIMIT) {
            if (ileriTries >= MAX_ATTEMPTS) {
                svc.stopWithWarning("⚠ İleri çalışmadı, durdu")
                return
            }
            ileriTries++
            prevVillage = cur
            ileriAt = now
            pending = null
            svc.log("Toplam $total ≤ 3M → İleri")
            tapRef(frame, 2220f, 1148f)
        } else {
            svc.log("Toplam $total > 3M → saldırı")
            deploy(frame)
        }
    }

    private suspend fun deploy(frame: Frame) {
        deployed = true
        prevVillage = null
        pending = null
        ileriTries = 0

        tapRef(frame, CARD_X.toFloat(), CARD_Y.toFloat())   // beyaz saçlı "x40 / 11" kartı, tek kez
        delay(120)

        val used = ArrayList<IntArray>()
        for (p in DEPLOY) {
            if (!svc.running) return
            val pick = choosePoint(frame.small, p, used) ?: continue
            used.add(pick)
            tapRef(frame, pick[0].toFloat(), pick[1].toFloat())
            svc.log("Bırakma ${used.size}/20")
            delay(TAP_GAP_MS)
        }
        svc.log("Bırakma bitti (${used.size}/20)")
    }

    private fun forbidden(x: Int, y: Int): Boolean {
        for (r in FORBIDDEN) if (x >= r[0] && x <= r[2] && y >= r[1] && y <= r[3]) return true
        return false
    }

    private fun farEnough(x: Int, y: Int, used: List<IntArray>): Boolean {
        for (u in used) {
            val dx = (u[0] - x).toLong()
            val dy = (u[1] - y).toLong()
            if (dx * dx + dy * dy < 100L * 100L) return false
        }
        return true
    }

    private fun usable(small: android.graphics.Bitmap, x: Int, y: Int, used: List<IntArray>): Boolean =
        x in 30..2389 && y in 30..1260 && !forbidden(x, y) && farEnough(x, y, used) && Scenes.isGrass(small, x, y)

    /** Listedeki nokta yeşil dış alandaysa onu, değilse yakınında yeşil bir nokta seç; bulunamazsa atla. */
    private fun choosePoint(small: android.graphics.Bitmap, p: IntArray, used: List<IntArray>): IntArray? {
        if (usable(small, p[0], p[1], used)) return p
        for (r in intArrayOf(70, 130, 200)) {
            for (a in 0 until 8) {
                val ang = a * Math.PI / 4
                val x = p[0] + (r * cos(ang)).toInt()
                val y = p[1] + (r * sin(ang)).toInt()
                if (usable(small, x, y, used)) return intArrayOf(x, y)
            }
        }
        return null
    }

    private suspend fun tapRef(frame: Frame, xRef: Float, yRef: Float) {
        Ref.map(xRef, yRef, frame.w, frame.h, pt)
        svc.tap(pt.x, pt.y)
    }
}
