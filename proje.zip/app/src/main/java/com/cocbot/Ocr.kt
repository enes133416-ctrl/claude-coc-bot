package com.cocbot

import android.graphics.Bitmap
import android.graphics.PointF
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** ML Kit (cihaz içi, Latin) ile küçük bölgeden sayı okuma. Ana döngü thread'inde çağrılır (arka plan). */
object Ocr {
    private val rec by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    fun warmUp() { rec }

    /** Referans koordinatlı dikdörtgeni orijinal çözünürlükten kırpıp sayıyı okur. Okunamazsa null. */
    fun readNumber(full: Bitmap, x0: Int, y0: Int, x1: Int, y1: Int): Long? {
        val a = PointF()
        val b = PointF()
        Ref.map(x0.toFloat(), y0.toFloat(), full.width, full.height, a)
        Ref.map(x1.toFloat(), y1.toFloat(), full.width, full.height, b)
        val l = a.x.toInt().coerceIn(0, full.width - 8)
        val t = a.y.toInt().coerceIn(0, full.height - 8)
        val w = (b.x.toInt() - l).coerceIn(8, full.width - l)
        val h = (b.y.toInt() - t).coerceIn(8, full.height - t)
        var crop: Bitmap? = null
        var big: Bitmap? = null
        try {
            crop = Bitmap.createBitmap(full, l, t, w, h)
            big = Bitmap.createScaledBitmap(crop, w * 2, h * 2, true)
            val text = Tasks.await(rec.process(InputImage.fromBitmap(big, 0))).text
            return parse(text)
        } catch (e: Exception) {
            return null
        } finally {
            big?.recycle()
            if (crop !== big) crop?.recycle()
        }
    }

    private fun parse(text: String): Long? {
        val sb = StringBuilder()
        for (c in text) {
            when {
                c.isDigit() -> sb.append(c)
                c == 'O' || c == 'o' -> sb.append('0')
                c == 'I' || c == 'l' || c == '|' -> sb.append('1')
                c == 'S' || c == 's' -> sb.append('5')
                c == 'B' -> sb.append('8')
                c == 'Z' -> sb.append('2')
            }
        }
        if (sb.isEmpty() || sb.length > 9) return null
        return sb.toString().toLongOrNull()
    }
}
