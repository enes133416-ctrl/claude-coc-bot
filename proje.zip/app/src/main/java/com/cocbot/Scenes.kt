package com.cocbot

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PointF
import kotlin.math.abs
import kotlin.math.max

enum class Scene { HOME, WAR_MENU, ARMY, ATTACK_PREP, RESULT }

/** Referans koordinatta (x,y) noktasının beklenen rengi. */
class Probe(val x: Int, val y: Int, val r: Int, val g: Int, val b: Int)

/** Ucuz piksel örnekleme ile sahne tanıma (küçültülmüş görüntüde). */
object Scenes {
    private const val TOL = 45
    private val pt = PointF()
    private val rgb = IntArray(3)

    private val sigs: List<Pair<Scene, Array<Probe>>> = listOf(
        Scene.HOME to arrayOf(
            Probe(60, 1290, 250, 202, 14), Probe(240, 1290, 250, 202, 14),
            Probe(2200, 1290, 250, 202, 14), Probe(2370, 1290, 250, 202, 14),
            Probe(60, 1460, 252, 181, 15), Probe(2190, 1470, 253, 177, 14),
            Probe(2340, 700, 206, 193, 148)
        ),
        Scene.WAR_MENU to arrayOf(
            Probe(150, 1060, 248, 173, 45), Probe(620, 1060, 248, 173, 45),
            Probe(200, 995, 254, 204, 82), Probe(580, 995, 254, 204, 83),
            Probe(200, 1130, 250, 180, 52), Probe(580, 1130, 250, 180, 52),
            Probe(420, 1440, 155, 219, 85), Probe(700, 1300, 96, 66, 55),
            Probe(1300, 1300, 96, 66, 55), Probe(60, 600, 104, 71, 56)
        ),
        Scene.ARMY to arrayOf(
            Probe(2205, 275, 205, 18, 22), Probe(2250, 275, 189, 16, 21),
            Probe(2230, 1260, 157, 230, 78), Probe(2200, 1000, 93, 64, 52),
            Probe(160, 330, 139, 90, 66), Probe(1200, 330, 139, 90, 66)
        ),
        Scene.ATTACK_PREP to arrayOf(
            Probe(2060, 1085, 253, 203, 76), Probe(2380, 1085, 254, 203, 75),
            Probe(2060, 1215, 242, 109, 17), Probe(2380, 1215, 242, 109, 17),
            Probe(60, 1215, 206, 13, 14), Probe(260, 1215, 206, 13, 14),
            Probe(2300, 1400, 10, 15, 8), Probe(2100, 1400, 2, 6, 3),
            Probe(2300, 1480, 7, 6, 7), Probe(1900, 1480, 6, 12, 2)
        ),
        Scene.RESULT to arrayOf(
            Probe(1060, 1350, 109, 187, 30), Probe(1370, 1350, 110, 187, 31),
            Probe(1060, 1255, 225, 248, 137), Probe(1370, 1255, 216, 245, 126),
            Probe(640, 470, 197, 143, 16), Probe(1760, 470, 240, 186, 48)
        )
    )

    /** (xRef,yRef) civarının 3x3 ortalama rengini out'a yazar. */
    private fun avg(bmp: Bitmap, xRef: Int, yRef: Int, out: IntArray) {
        Ref.map(xRef.toFloat(), yRef.toFloat(), bmp.width, bmp.height, pt)
        val cx = pt.x.toInt()
        val cy = pt.y.toInt()
        var r = 0; var g = 0; var b = 0; var n = 0
        for (dy in -1..1) for (dx in -1..1) {
            val x = (cx + dx).coerceIn(0, bmp.width - 1)
            val y = (cy + dy).coerceIn(0, bmp.height - 1)
            val c = bmp.getPixel(x, y)
            r += Color.red(c); g += Color.green(c); b += Color.blue(c); n++
        }
        out[0] = r / n; out[1] = g / n; out[2] = b / n
    }

    /** Hangi sahnedeyiz? Tanınamazsa null (bu durumda bot hiçbir yere dokunmaz). */
    fun detect(small: Bitmap): Scene? {
        for ((scene, probes) in sigs) {
            var ok = 0
            for (p in probes) {
                avg(small, p.x, p.y, rgb)
                val d = max(abs(rgb[0] - p.r), max(abs(rgb[1] - p.g), abs(rgb[2] - p.b)))
                if (d <= TOL) ok++
            }
            if (ok >= probes.size - 1) return scene
        }
        return null
    }

    /** Nokta yeşil çim mi? (köy zemini sarımsı, su mavi, arayüz koyu lacivert, sınır çizgisi kırmızı) */
    fun isGrass(small: Bitmap, xRef: Int, yRef: Int): Boolean {
        avg(small, xRef, yRef, rgb)
        return rgb[1] >= rgb[0] + 4 && rgb[1] - rgb[2] >= 25 && rgb[1] >= 25
    }
}
